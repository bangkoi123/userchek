import React, { useState, useCallback, useEffect } from 'react';
import { useDropzone } from 'react-dropzone';
import { useAuth } from '../context/AuthContext';
import { uploadFile, apiCall } from '../utils/api';
import { useJobProgress } from '../hooks/useSocket';
import { 
  Upload, 
  File, 
  CheckCircle, 
  AlertCircle,
  Download,
  Trash2,
  FileSpreadsheet,
  FileText,
  Loader2,
  Info,
  Wifi,
  WifiOff,
  Clock
} from 'lucide-react';
import toast from 'react-hot-toast';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';

const BulkCheck = () => {
  const { user } = useAuth();
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [currentJobId, setCurrentJobId] = useState(null);
  const [realTimeProgress, setRealTimeProgress] = useState(null);
  const [validateWhatsapp, setValidateWhatsapp] = useState(true);
  const [validateTelegram, setValidateTelegram] = useState(true);
  const [validationMethod, setValidationMethod] = useState('standard');
  const [platformSettings, setPlatformSettings] = useState({
    whatsapp_enabled: true,
    telegram_enabled: true
  });

  // Progress Modal States
  const [showProgressModal, setShowProgressModal] = useState(() => {
    const saved = localStorage.getItem('bulk_check_progress_modal');
    return saved ? JSON.parse(saved) : false;
  });
  const [currentJob, setCurrentJob] = useState(() => {
    const saved = localStorage.getItem('bulk_check_current_job');
    return saved ? JSON.parse(saved) : null;
  });
  const [showResultsModal, setShowResultsModal] = useState(false);
  const [jobResults, setJobResults] = useState(null);
  const [resultsPage, setResultsPage] = useState(1);
  const [completedJobs, setCompletedJobs] = useState(() => {
    const saved = localStorage.getItem('bulk_check_completed_jobs');
    return saved ? JSON.parse(saved) : [];
  });
  const RESULTS_PER_PAGE = 100;

  // Persistence effects
  useEffect(() => {
    localStorage.setItem('bulk_check_progress_modal', JSON.stringify(showProgressModal));
  }, [showProgressModal]);

  useEffect(() => {
    localStorage.setItem('bulk_check_current_job', JSON.stringify(currentJob));
  }, [currentJob]);

  useEffect(() => {
    localStorage.setItem('bulk_check_completed_jobs', JSON.stringify(completedJobs));
  }, [completedJobs]);

  // Recovery effect - resume monitoring if there's an active job
  useEffect(() => {
    if (currentJob && !realTimeProgress) {
      setCurrentJobId(currentJob.job_id);
      startListening();
    }
  }, []);
  
  // Real-time job progress hook
  const { progress, isListening, startListening, stopListening } = useJobProgress(currentJobId);

  // Update realTimeProgress when progress changes
  useEffect(() => {
    if (progress) {
      setRealTimeProgress(progress);
      
      // Check if job is completed and add to completed jobs
      if (progress.status === 'completed' && currentJob) {
        const completedJob = {
          ...currentJob,
          completed_at: new Date().toISOString(),
          results: progress.results || {}
        };
        
        setCompletedJobs(prev => {
          const existing = prev.find(job => job.job_id === currentJob.job_id);
          if (!existing) {
            return [completedJob, ...prev].slice(0, 10); // Keep last 10 completed jobs
          }
          return prev;
        });
      }
    }
  }, [progress, currentJob]);

  // FALLBACK: Polling job status if WebSocket fails
  useEffect(() => {
    let pollingInterval;
    
    if (currentJobId && showProgressModal && !realTimeProgress) {
      // Start polling after 10 seconds if no WebSocket data
      const startPolling = setTimeout(() => {
        pollingInterval = setInterval(async () => {
          try {
            const jobData = await apiCall(`/api/jobs/${currentJobId}`);
            if (jobData) {
              const progressData = {
                job_id: currentJobId,
                status: jobData.status,
                total_numbers: jobData.total_numbers,
                processed_numbers: jobData.processed_numbers,
                results: jobData.results
              };
              
              setRealTimeProgress(progressData);
              
              // Stop polling when completed
              if (jobData.status === 'completed') {
                clearInterval(pollingInterval);
                
                // Add to completed jobs
                const completedJob = {
                  ...currentJob,
                  completed_at: new Date().toISOString(),
                  results: jobData.results || {}
                };
                
                setCompletedJobs(prev => {
                  const existing = prev.find(job => job.job_id === currentJob.job_id);
                  if (!existing) {
                    return [completedJob, ...prev].slice(0, 10);
                  }
                  return prev;
                });
              }
            }
          } catch (error) {
            console.error('Polling error:', error);
          }
        }, 2000); // Poll every 2 seconds
      }, 10000); // Start after 10 seconds
      
      return () => {
        clearTimeout(startPolling);
        if (pollingInterval) {
          clearInterval(pollingInterval);
        }
      };
    }
  }, [currentJobId, showProgressModal, realTimeProgress, currentJob]);

  useEffect(() => {
    fetchPlatformSettings();
  }, []);

  const fetchPlatformSettings = async () => {
    try {
      const settings = await apiCall('/api/platform-settings');
      setPlatformSettings(settings);
      
      // If platform is disabled, uncheck it
      if (!settings.whatsapp_enabled) {
        setValidateWhatsapp(false);
      }
      if (!settings.telegram_enabled) {
        setValidateTelegram(false);
      }
    } catch (error) {
      console.error('Error fetching platform settings:', error);
    }
  };

  // Handle real-time progress updates
  useEffect(() => {
    if (progress) {
      setRealTimeProgress(progress);
      
      if (progress.status === 'completed') {
        toast.success(`🎉 Validasi selesai! ${progress.results?.whatsapp_active || 0} WhatsApp aktif, ${progress.results?.telegram_active || 0} Telegram aktif`);
        setTimeout(() => {
          setCurrentJobId(null);
          setRealTimeProgress(null);
          stopListening();
        }, 5000); // Show completion for 5 seconds
      }
    }
  }, [progress, stopListening]);

  // Sample CSV for download
  const sampleCSV = `name,phone_number
Koi,+6281234567890  
Budi,+6289876543210
Sari,+6285555666777
Andi,08123456789
Maya,+628111222333`;

  const downloadSampleCSV = () => {
    const element = document.createElement("a");
    const file = new Blob([sampleCSV], { type: 'text/csv' });
    element.href = URL.createObjectURL(file);
    element.download = "sample_phone_numbers.csv";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    toast.success('Sample CSV downloaded!');
  };

  const onDrop = useCallback((acceptedFiles, rejectedFiles) => {
    // Handle rejected files
    if (rejectedFiles.length > 0) {
      rejectedFiles.forEach(({ file, errors }) => {
        errors.forEach((error) => {
          if (error.code === 'file-too-large') {
            toast.error(`File ${file.name} terlalu besar (max 10MB)`);
          } else if (error.code === 'file-invalid-type') {
            toast.error(`File ${file.name} format tidak didukung`);
          }
        });
      });
    }

    // Handle accepted files
    acceptedFiles.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const preview = e.target.result;
        setFiles(prev => [...prev, {
          id: Date.now() + Math.random(),
          file,
          preview,
          status: 'ready',
          error: null
        }]);
      };
      reader.readAsText(file);
    });
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv'],
      'application/vnd.ms-excel': ['.xls'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx']
    },
    maxSize: 10 * 1024 * 1024, // 10MB
    multiple: true
  });

  const removeFile = (id) => {
    setFiles(prev => prev.filter(file => file.id !== id));
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (fileName) => {
    const extension = fileName.split('.').pop().toLowerCase();
    if (extension === 'csv') {
      return <FileText className="h-8 w-8 text-green-500" />;
    } else if (extension === 'xlsx' || extension === 'xls') {
      return <FileSpreadsheet className="h-8 w-8 text-blue-500" />;
    }
    return <File className="h-8 w-8 text-gray-500" />;
  };

  const estimateCredits = () => {
    let totalRows = 0;
    files.forEach(fileItem => {
      if (fileItem.preview) {
        const lines = fileItem.preview.split('\n').filter(line => line.trim());
        totalRows += Math.max(0, lines.length - 1); // Subtract header row
      }
    });
    
    // Calculate credits based on platform selection and validation method
    let creditsPerNumber = 0;
    if (validateWhatsapp) {
      creditsPerNumber += validationMethod === 'standard' ? 1 : 3;
    }
    if (validateTelegram) creditsPerNumber += 1;
    
    return totalRows * creditsPerNumber;
  };

  const startValidation = async () => {
    if (files.length === 0) {
      toast.error('Pilih file terlebih dahulu');
      return;
    }

    if (!validateWhatsapp && !validateTelegram) {
      toast.error('Pilih minimal satu platform untuk validasi');
      return;
    }

    const estimatedCredits = estimateCredits();
    if (user?.credits < estimatedCredits) {
      toast.error(`Kredit tidak mencukupi. Dibutuhkan ${estimatedCredits} kredit, tersisa ${user?.credits || 0}`);
      return;
    }

    setUploading(true);
    setUploadProgress(0);

    try {
      for (let i = 0; i < files.length; i++) {
        const fileItem = files[i];
        
        // Update file status
        setFiles(prev => prev.map(f => 
          f.id === fileItem.id ? { ...f, status: 'uploading' } : f
        ));

        try {
          const formData = new FormData();
          formData.append('file', fileItem.file);
          
          // Send boolean values as strings for FastAPI Form parameters
          formData.append('validate_whatsapp', validateWhatsapp ? 'true' : 'false');
          formData.append('validate_telegram', validateTelegram ? 'true' : 'false');
          formData.append('validation_method', validationMethod);

          console.log('Starting upload for file:', fileItem.file.name);
          console.log('Platform settings:', { validateWhatsapp, validateTelegram, validationMethod });
          console.log('FormData entries:');
          for (let [key, value] of formData.entries()) {
            console.log(`${key}:`, value && value.constructor && value.constructor.name === 'File' ? `File(${value.name})` : value);
          }
          
          const response = await apiCall('/api/validation/bulk-check', 'POST', formData, {
            onUploadProgress: (progressEvent) => {
              const percentCompleted = Math.round(
                (progressEvent.loaded * 100) / progressEvent.total
              );
              setUploadProgress(Math.round(((i / files.length) * 100) + (percentCompleted / files.length)));
            },
          });

          console.log('Upload response:', response);

          // Verify we have a successful response
          if (response && response.job_id) {
            // Update file status to success
            setFiles(prev => prev.map(f => 
              f.id === fileItem.id ? { ...f, status: 'success' } : f
            ));

            toast.success(`File ${fileItem.file.name} berhasil diupload!`);
            
            // Set current job and show progress modal
            setCurrentJob({
              job_id: response.job_id,
              total_numbers: response.total_numbers || 0,
              fileName: fileItem.file.name,
              platforms: { whatsapp: validateWhatsapp, telegram: validateTelegram }
            });
            setShowProgressModal(true);
            
            // Start real-time monitoring
            setCurrentJobId(response.job_id);
            startListening();
          } else {
            throw new Error('Response tidak valid atau tidak ada job_id');
          }
          
        } catch (error) {
          console.error('Upload error for file:', fileItem.file.name);
          console.error('Error details:', {
            status: error.response?.status,
            statusText: error.response?.statusText,
            data: error.response?.data,
            message: error.message,
            config: error.config
          });
          
          // Update file status to error
          setFiles(prev => prev.map(f => 
            f.id === fileItem.id ? { 
              ...f, 
              status: 'error', 
              error: error.response?.data?.detail || error.message || 'Upload gagal' 
            } : f
          ));
          
          const errorMessage = error.response?.data?.detail || error.message || 'Upload gagal';
          toast.error(`Error uploading ${fileItem.file.name}: ${errorMessage}`);
        }
      }
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };

  return (
    <div className="space-y-6">
      {/* Compact Header */}
      <div className="bg-gradient-to-r from-primary-600 to-primary-700 rounded-lg p-4 text-white mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="p-2 bg-white/20 rounded-lg mr-3">
              <FileText className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold">Bulk Check - Validasi Massal</h1>
              <p className="text-primary-100 text-sm">
                Upload CSV untuk validasi banyak nomor sekaligus
              </p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold">{user?.credits || 0}</div>
            <div className="text-primary-100 text-xs">kredit tersisa</div>
          </div>
        </div>
      </div>

      {/* Completed Jobs Section - MOVED TO TOP */}
      <div className="card p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-gray-900 dark:text-white">
            🎯 Hasil Validasi Terbaru
          </h3>
          <div className="flex items-center space-x-3">
            <span className="text-sm text-gray-500 dark:text-gray-400">
              {completedJobs.length} hasil tersimpan
            </span>
            {completedJobs.length > 0 && (
              <button
                onClick={() => {
                  setCompletedJobs([]);
                  toast.success('Riwayat hasil berhasil dibersihkan');
                }}
                className="text-xs text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 px-2 py-1 rounded hover:bg-red-50 dark:hover:bg-red-900/20"
              >
                Hapus Semua
              </button>
            )}
          </div>
        </div>
        
        {completedJobs.length > 0 ? (
          <div className="overflow-x-auto">
            <div className="flex space-x-4 pb-4" style={{ minWidth: 'max-content' }}>
              {completedJobs.map((job, index) => (
                <div key={job.job_id} className={`bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-600 rounded-lg p-4 border-l-4 ${index === 0 ? 'border-green-500 shadow-lg' : 'border-blue-300'} transition-all hover:shadow-md flex-shrink-0 w-80`}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3 flex-1 min-w-0">
                      <div className="p-2 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
                        <FileText className="h-4 w-4 text-primary-600 dark:text-primary-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2">
                          <span className="font-semibold text-gray-900 dark:text-white truncate">
                            {job.fileName}
                          </span>
                          {index === 0 && (
                            <span className="px-2 py-1 bg-gradient-to-r from-green-100 to-green-200 text-green-800 dark:from-green-900 dark:to-green-800 dark:text-green-200 rounded-full text-xs font-medium animate-pulse flex-shrink-0">
                              🆕 Terbaru
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                          {format(new Date(job.completed_at), 'dd/MM HH:mm', { locale: id })} • {job.total_numbers} nomor
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        const updatedJobs = completedJobs.filter(j => j.job_id !== job.job_id);
                        setCompletedJobs(updatedJobs);
                        toast.success('Hasil validasi berhasil dihapus');
                      }}
                      className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 p-1 rounded hover:bg-red-50 dark:hover:bg-red-900/20 flex-shrink-0 ml-2"
                      title="Hapus hasil ini"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2 flex-wrap">
                      {job.platforms.whatsapp && (
                        <span className="px-3 py-1 bg-gradient-to-r from-green-100 to-green-200 text-green-800 dark:from-green-900 dark:to-green-800 dark:text-green-200 rounded-full text-xs font-semibold">
                          ✅ WA: {job.results.whatsapp_active || 0}
                        </span>
                      )}
                      {job.platforms.telegram && (
                        <span className="px-3 py-1 bg-gradient-to-r from-blue-100 to-blue-200 text-blue-800 dark:from-blue-900 dark:to-blue-800 dark:text-blue-200 rounded-full text-xs font-semibold">
                          ✅ TG: {job.results.telegram_active || 0}
                        </span>
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={async () => {
                          try {
                            const jobData = await apiCall(`/api/jobs/${job.job_id}`);
                            const csvContent = generateCSV(jobData.results?.details || []);
                            downloadCSV(csvContent, `validation-results-${job.fileName}-${job.completed_at.slice(0,10)}.csv`);
                            toast.success('File CSV berhasil didownload!');
                          } catch (error) {
                            toast.error('Gagal mendownload hasil');
                          }
                        }}
                        className="px-3 py-1.5 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white text-xs font-medium rounded transition-all"
                        title="Download CSV"
                      >
                        📥
                      </button>
                      <button
                        onClick={async () => {
                          try {
                            const jobData = await apiCall(`/api/jobs/${job.job_id}`);
                            setJobResults(jobData);
                            setShowResultsModal(true);
                          } catch (error) {
                            toast.error('Gagal memuat hasil');
                          }
                        }}
                        className="px-3 py-1.5 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white text-xs font-medium rounded transition-all"
                      >
                        📋 Detail
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="text-center py-6 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <div className="inline-flex items-center justify-center w-12 h-12 bg-gray-200 dark:bg-gray-700 rounded-full mb-3">
              <FileText className="h-6 w-6 text-gray-400" />
            </div>
            <p className="text-gray-500 dark:text-gray-400 font-medium">
              Belum ada hasil validasi
            </p>
            <p className="text-sm text-gray-400 dark:text-gray-500 mt-1">
              Upload file CSV untuk memulai validasi
            </p>
          </div>
        )}
      </div>



      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Upload Area */}
        <div className="lg:col-span-2 space-y-6">
          {/* Validation Method Selection */}
          <div className="card p-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              🎯 Pilih Metode Validasi
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              {/* Standard Method */}
              <label className={`method-card cursor-pointer border-2 rounded-lg p-4 transition-all ${
                validationMethod === 'standard' 
                  ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20' 
                  : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
              }`}>
                <input 
                  type="radio" 
                  value="standard" 
                  checked={validationMethod === 'standard'}
                  onChange={(e) => setValidationMethod(e.target.value)}
                  className="sr-only"
                />
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <span className="text-2xl">📊</span>
                  </div>
                  <div className="ml-3 flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-sm font-semibold text-gray-900 dark:text-white">
                        Standard Validation
                      </h3>
                      <span className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 px-2 py-1 rounded text-xs font-medium">
                        1 💎
                      </span>
                    </div>
                    <div className="text-xs text-gray-600 dark:text-gray-400 mb-2">
                      <span className="inline-flex items-center">
                        ✅ Akurasi: 95%+ • ⚡ Speed: Very Fast
                      </span>
                    </div>
                    <ul className="text-xs text-gray-600 dark:text-gray-400 space-y-1">
                      <li>✅ Status active/inactive</li>
                      <li>✅ Reliable CheckNumber.ai API</li>
                      <li>✅ Business-grade SLA</li>
                      <li>✅ Bulk processing</li>
                    </ul>
                  </div>
                </div>
              </label>
              
              {/* Enhanced Deep Link Method */}
              <label className={`method-card cursor-pointer border-2 rounded-lg p-4 transition-all ${
                validationMethod === 'deeplink_profile' 
                  ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20' 
                  : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
              }`}>
                <input 
                  type="radio" 
                  value="deeplink_profile" 
                  checked={validationMethod === 'deeplink_profile'}
                  onChange={(e) => setValidationMethod(e.target.value)}
                  className="sr-only"
                />
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <span className="text-2xl">🔍</span>
                  </div>
                  <div className="ml-3 flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-sm font-semibold text-gray-900 dark:text-white">
                        Deep Link Profile
                      </h3>
                      <div className="flex items-center space-x-1">
                        <span className="bg-gradient-to-r from-purple-100 to-pink-100 text-purple-800 dark:from-purple-900 dark:to-pink-900 dark:text-purple-200 px-2 py-1 rounded text-xs font-medium">
                          3 💎
                        </span>
                        <span className="bg-gradient-to-r from-yellow-100 to-orange-100 text-yellow-800 dark:from-yellow-900 dark:to-orange-900 dark:text-yellow-200 px-2 py-1 rounded text-xs font-bold">
                          PREMIUM
                        </span>
                      </div>
                    </div>
                    <div className="text-xs text-gray-600 dark:text-gray-400 mb-2">
                      <span className="inline-flex items-center">
                        ✅ Akurasi: 90%+ • 🔍 Profile: Detailed
                      </span>
                    </div>
                    <ul className="text-xs text-gray-600 dark:text-gray-400 space-y-1">
                      <li>✅ Status active/inactive</li>
                      <li>✅ Profile picture visibility</li>
                      <li>✅ Last seen information</li>
                      <li>✅ Business account detection</li>
                      <li>⭐ Human-like WhatsApp access</li>
                    </ul>
                  </div>
                </div>
              </label>
            </div>
            
            <div className="bg-amber-50 dark:bg-amber-900/20 rounded-lg p-3">
              <p className="text-sm text-amber-700 dark:text-amber-300">
                💡 <strong>Rekomendasi:</strong> {
                  validationMethod === 'standard' 
                    ? 'Standard method cocok untuk validasi massal dengan akurasi tinggi dan kecepatan optimal.'
                    : 'Deep Link Profile memberikan informasi detail profil WhatsApp untuk analisis mendalam.'
                }
              </p>
            </div>
          </div>

          {/* Platform Selection */}
          <div className="card p-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              📱 Platform Selection
            </h2>
            
            <div className="space-y-3">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="whatsapp-bulk"
                  checked={validateWhatsapp}
                  onChange={(e) => setValidateWhatsapp(e.target.checked)}
                  disabled={!platformSettings.whatsapp_enabled}
                  className="w-4 h-4 text-primary-600 bg-gray-100 border-gray-300 rounded focus:ring-primary-500 dark:focus:ring-primary-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                />
                <label htmlFor="whatsapp-bulk" className="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">
                  <span className="flex items-center">
                    WhatsApp ({validationMethod === 'standard' ? '1' : '3'} credit per nomor)
                    {!platformSettings.whatsapp_enabled && (
                      <span className="ml-2 text-xs text-red-500">(Disabled)</span>
                    )}
                  </span>
                </label>
              </div>
              
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="telegram-bulk"
                  checked={validateTelegram}
                  onChange={(e) => setValidateTelegram(e.target.checked)}
                  disabled={!platformSettings.telegram_enabled}
                  className="w-4 h-4 text-primary-600 bg-gray-100 border-gray-300 rounded focus:ring-primary-500 dark:focus:ring-primary-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                />
                <label htmlFor="telegram-bulk" className="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">
                  <span className="flex items-center">
                    Telegram (1 credit per nomor)
                    {!platformSettings.telegram_enabled && (
                      <span className="ml-2 text-xs text-red-500">(Disabled)</span>
                    )}
                  </span>
                </label>
              </div>
            </div>
            
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 mt-4">
              <p className="text-sm text-blue-700 dark:text-blue-300">
                💡 <strong>Tips:</strong> Pilih platform yang ingin divalidasi. Biaya dihitung berdasarkan metode dan platform yang dipilih.
              </p>
            </div>
          </div>

          {/* File Upload */}
          <div className="card p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                Upload File
              </h2>
              <button
                onClick={downloadSampleCSV}
                className="btn-secondary text-sm"
              >
                <Download className="h-4 w-4 mr-2" />
                Download Sample
              </button>
            </div>
            
            <div
              {...getRootProps()}
              className={`
                drop-zone cursor-pointer
                ${isDragActive ? 'active' : ''}
                ${uploading ? 'pointer-events-none opacity-50' : ''}
              `}
            >
              <input {...getInputProps()} />
              <div className="text-center">
                <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                {isDragActive ? (
                  <p className="text-lg text-primary-600 dark:text-primary-400 font-medium">
                    Lepaskan file di sini...
                  </p>
                ) : (
                  <>
                    <p className="text-lg text-gray-900 dark:text-white font-medium mb-2">
                      Drag & drop file atau klik untuk pilih
                    </p>
                    <p className="text-gray-600 dark:text-gray-400">
                      Mendukung CSV, XLS, XLSX (max 10MB)
                    </p>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* File List */}
          {files.length > 0 && (
            <div className="card p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                  File yang Dipilih ({files.length})
                </h2>
                <button
                  onClick={() => setFiles([])}
                  className="text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 text-sm font-medium"
                  disabled={uploading}
                >
                  Hapus Semua
                </button>
              </div>

              <div className="space-y-3">
                {files.map((fileItem) => (
                  <div key={fileItem.id} className="border border-gray-200 dark:border-gray-600 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        {getFileIcon(fileItem.file.name)}
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">
                            {fileItem.file.name}
                          </p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {formatFileSize(fileItem.file.size)} • {fileItem.file.type || 'Unknown type'}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        {fileItem.status === 'ready' && (
                          <span className="px-2 py-1 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 rounded-full text-xs font-medium">
                            Siap
                          </span>
                        )}
                        {fileItem.status === 'uploading' && (
                          <span className="px-2 py-1 bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200 rounded-full text-xs font-medium flex items-center">
                            <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                            Upload...
                          </span>
                        )}
                        {fileItem.status === 'success' && (
                          <span className="px-2 py-1 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 rounded-full text-xs font-medium flex items-center">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Berhasil
                          </span>
                        )}
                        {fileItem.status === 'error' && (
                          <span className="px-2 py-1 bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200 rounded-full text-xs font-medium flex items-center">
                            <AlertCircle className="h-3 w-3 mr-1" />
                            Error
                          </span>
                        )}
                        
                        {!uploading && (
                          <button
                            onClick={() => removeFile(fileItem.id)}
                            className="p-1 text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    </div>

                    {fileItem.error && (
                      <div className="mt-2 p-2 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded text-sm text-red-700 dark:text-red-300">
                        {fileItem.error}
                      </div>
                    )}

                    {fileItem.preview && (
                      <div className="mt-3 text-sm text-gray-600 dark:text-gray-400">
                        Preview: {Math.max(0, fileItem.preview.split('\n').filter(line => line.trim()).length - 1)} baris data
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Progress Bar */}
              {uploading && (
                <div className="mt-4">
                  <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400 mb-2">
                    <span>Upload Progress</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <div className="progress-bar">
                    <div 
                      className="progress-fill"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Real-time Progress */}
              {realTimeProgress && (
                <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-blue-900 dark:text-blue-100 flex items-center">
                      <Wifi className="h-4 w-4 mr-2" />
                      Live Progress - Job {realTimeProgress.job_id?.substring(0, 8)}...
                    </h4>
                    <span className="text-sm text-blue-700 dark:text-blue-300">
                      {realTimeProgress.status === 'completed' ? '✅ Selesai' : '🔄 Memproses'}
                    </span>
                  </div>
                  
                  <div className="progress-bar mb-2">
                    <div 
                      className="progress-fill transition-all duration-500"
                      style={{ width: `${realTimeProgress.progress_percentage || 0}%` }}
                    />
                  </div>
                  
                  <div className="flex justify-between text-sm text-blue-700 dark:text-blue-300">
                    <span>
                      {realTimeProgress.processed_numbers || 0} / {realTimeProgress.total_numbers || 0} nomor
                    </span>
                    <span>{realTimeProgress.progress_percentage || 0}%</span>
                  </div>
                  
                  {realTimeProgress.current_phone && (
                    <div className="mt-2 text-xs text-blue-600 dark:text-blue-400">
                      📱 Sedang memproses: {realTimeProgress.current_phone}
                      {realTimeProgress.last_result && (
                        <span className="ml-2">
                          (WA: {realTimeProgress.last_result.whatsapp}, TG: {realTimeProgress.last_result.telegram})
                        </span>
                      )}
                    </div>
                  )}
                  
                  {realTimeProgress.status === 'completed' && realTimeProgress.results && (
                    <div className="mt-3 grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                      <div className="text-center p-2 bg-green-100 dark:bg-green-900 rounded">
                        <div className="font-bold text-green-700 dark:text-green-300">
                          {realTimeProgress.results.whatsapp_active || 0}
                        </div>
                        <div className="text-green-600 dark:text-green-400">WA Aktif</div>
                      </div>
                      <div className="text-center p-2 bg-blue-100 dark:bg-blue-900 rounded">
                        <div className="font-bold text-blue-700 dark:text-blue-300">
                          {realTimeProgress.results.telegram_active || 0}
                        </div>
                        <div className="text-blue-600 dark:text-blue-400">TG Aktif</div>
                      </div>
                      <div className="text-center p-2 bg-red-100 dark:bg-red-900 rounded">
                        <div className="font-bold text-red-700 dark:text-red-300">
                          {realTimeProgress.results.inactive || 0}
                        </div>
                        <div className="text-red-600 dark:text-red-400">Tidak Aktif</div>
                      </div>
                      <div className="text-center p-2 bg-yellow-100 dark:bg-yellow-900 rounded">
                        <div className="font-bold text-yellow-700 dark:text-yellow-300">
                          {realTimeProgress.results.errors || 0}
                        </div>
                        <div className="text-yellow-600 dark:text-yellow-400">Error</div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Action Button */}
              <button
                onClick={startValidation}
                disabled={uploading || files.length === 0 || files.some(f => f.status === 'error') || 
                         (!validateWhatsapp && !validateTelegram)}
                className="w-full btn-primary mt-4 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {uploading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Memproses...
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4 mr-2" />
                    Mulai Validasi ({estimateCredits()} kredit)
                  </>
                )}
              </button>
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Credit & Estimation */}
          <div className="card p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              Estimasi Biaya
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-600 dark:text-gray-400">Kredit tersisa</span>
                <span className="font-bold text-green-600 dark:text-green-400">
                  {user?.credits || 0}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600 dark:text-gray-400">Estimasi biaya</span>
                <span className="font-medium text-gray-900 dark:text-white">
                  {estimateCredits()} kredit
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600 dark:text-gray-400">Sisa setelah validasi</span>
                <span className={`font-medium ${
                  (user?.credits || 0) - estimateCredits() >= 0 
                    ? 'text-green-600 dark:text-green-400' 
                    : 'text-red-600 dark:text-red-400'
                }`}>
                  {(user?.credits || 0) - estimateCredits()}
                </span>
              </div>
            </div>
          </div>

          {/* Format Guide */}
          <div className="card p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              📋 Format File
            </h3>
            <div className="space-y-4">
              <div>
                <p className="font-medium text-gray-900 dark:text-white mb-2">Format 1 - Hanya Nomor:</p>
                <div className="bg-gray-100 dark:bg-gray-700 rounded p-2 text-sm font-mono">
                  phone_number<br/>
                  +628123456789<br/>
                  08234567890<br/>
                  628345678901
                </div>
              </div>
              
              <div>
                <p className="font-medium text-gray-900 dark:text-white mb-2">Format 2 - Nama + Nomor:</p>
                <div className="bg-gray-100 dark:bg-gray-700 rounded p-2 text-sm font-mono">
                  name,phone_number<br/>
                  Koi,+628123456789<br/>
                  Budi,08234567890<br/>
                  Sari,628345678901
                </div>
              </div>
              
              <div className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                <p>• Header wajib: <code>phone_number</code></p>
                <p>• Header opsional: <code>name</code>, <code>nama</code>, <code>identifier</code></p>
                <p>• Format nomor akan dinormalisasi otomatis</p>
                <p>• Duplikasi nomor akan dihapus</p>
                <p>• Max 1000 nomor per file</p>
              </div>
            </div>
          </div>

          {/* Completed Jobs Section moved to top */}

          {/* Tips */}
          <div className="card p-6">
            <div className="flex items-center mb-4">
              <Info className="h-5 w-5 text-primary-600 dark:text-primary-400 mr-2" />
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Tips Penggunaan</h3>
            </div>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <li className="flex items-start">
                <span className="inline-block w-2 h-2 bg-primary-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                Format CSV yang didukung: <code className="bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded text-xs mx-1">phone_number</code>
              </li>
              <li className="flex items-start">
                <span className="inline-block w-2 h-2 bg-primary-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                Opsional: Tambahkan kolom <code className="bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded text-xs mx-1">name</code> untuk identifikasi
              </li>
              <li className="flex items-start">
                <span className="inline-block w-2 h-2 bg-primary-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                Sistem akan otomatis menghapus nomor duplikat
              </li>
              <li className="flex items-start">
                <span className="inline-block w-2 h-2 bg-primary-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                Hasil dapat diunduh dalam format CSV atau dilihat detail
              </li>
              <li className="flex items-start">
                <span className="inline-block w-2 h-2 bg-primary-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                Progress akan tersimpan meski halaman di-refresh
              </li>
            </ul>
          </div>

          {/* Quick Stats */}
          <div className="card p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
              <Info className="h-5 w-5 mr-2" />
              Statistik
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">File dipilih</span>
                <span className="font-medium text-gray-900 dark:text-white">{files.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Total baris</span>
                <span className="font-medium text-gray-900 dark:text-white">
                  {files.reduce((total, file) => {
                    if (file.preview) {
                      const lines = file.preview.split('\n').filter(line => line.trim());
                      return total + Math.max(0, lines.length - 1);
                    }
                    return total;
                  }, 0)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Ukuran total</span>
                <span className="font-medium text-gray-900 dark:text-white">
                  {formatFileSize(files.reduce((total, file) => total + file.file.size, 0))}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Progress Modal */}
      {showProgressModal && currentJob && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-hidden">
            <div className="p-6 border-b border-gray-200 dark:border-gray-600">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  📊 Progress Validasi
                </h3>
                <button
                  onClick={() => setShowProgressModal(false)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
                >
                  ✕
                </button>
              </div>
            </div>

            <div className="p-6">
              {/* Job Info */}
              <div className="mb-6">
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-600 dark:text-gray-400">File</span>
                    <span className="text-sm text-gray-900 dark:text-white">{currentJob.fileName}</span>
                  </div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Nomor</span>
                    <span className="text-sm text-gray-900 dark:text-white">{currentJob.total_numbers}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-600 dark:text-gray-400">Platform</span>
                    <div className="flex space-x-2">
                      {currentJob.platforms.whatsapp && (
                        <span className="px-2 py-1 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 rounded text-xs">
                          WhatsApp
                        </span>
                      )}
                      {currentJob.platforms.telegram && (
                        <span className="px-2 py-1 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 rounded text-xs">
                          Telegram
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Progress Display */}
              <div className="mb-6">
                {realTimeProgress ? (
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Progress Validasi</span>
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {realTimeProgress.processed_numbers || 0} / {realTimeProgress.total_numbers || currentJob.total_numbers}
                      </span>
                    </div>
                    
                    {/* Progress Bar */}
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-4 mb-4 overflow-hidden">
                      <div 
                        className="bg-gradient-to-r from-blue-500 via-primary-500 to-green-500 h-4 rounded-full transition-all duration-500 relative"
                        style={{ 
                          width: `${(realTimeProgress.total_numbers || currentJob.total_numbers) > 0 ? 
                            ((realTimeProgress.processed_numbers || 0) / (realTimeProgress.total_numbers || currentJob.total_numbers)) * 100 : 0}%` 
                        }}
                      >
                        <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
                      </div>
                    </div>

                    <div className="text-center mb-4">
                      <span className="text-3xl font-bold text-primary-600 dark:text-primary-400">
                        {(realTimeProgress.total_numbers || currentJob.total_numbers) > 0 ? 
                          Math.round(((realTimeProgress.processed_numbers || 0) / (realTimeProgress.total_numbers || currentJob.total_numbers)) * 100) : 0}%
                      </span>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        {realTimeProgress.processed_numbers || 0} dari {realTimeProgress.total_numbers || currentJob.total_numbers} nomor diproses
                      </p>
                    </div>

                    {/* Status dengan animasi */}
                    <div className="text-center">
                      {realTimeProgress.status === 'completed' ? (
                        <div className="flex items-center justify-center text-green-600 dark:text-green-400 animate-bounce">
                          <CheckCircle className="h-6 w-6 mr-2" />
                          <span className="font-semibold text-lg">🎉 Validasi Selesai!</span>
                        </div>
                      ) : realTimeProgress.status === 'processing' ? (
                        <div className="flex items-center justify-center text-primary-600 dark:text-primary-400">
                          <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                          <span className="font-medium">Sedang Memproses Nomor...</span>
                        </div>
                      ) : (
                        <div className="flex items-center justify-center text-yellow-600 dark:text-yellow-400">
                          <Clock className="h-5 w-5 mr-2" />
                          <span className="font-medium">Menunggu Proses...</span>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-100 dark:bg-primary-900/30 rounded-full mb-4">
                      <Loader2 className="h-8 w-8 animate-spin text-primary-600 dark:text-primary-400" />
                    </div>
                    <p className="text-gray-600 dark:text-gray-400 font-medium">Memuat progress validasi...</p>
                    <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">Sistem sedang memproses permintaan Anda</p>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              {progress?.status === 'completed' && (
                <div className="space-y-3">
                  <div className="flex space-x-3">
                    <button
                      onClick={async () => {
                        try {
                          const jobData = await apiCall(`/api/jobs/${currentJob.job_id}`);
                          setJobResults(jobData);
                          setShowResultsModal(true);
                        } catch (error) {
                          toast.error('Gagal memuat hasil');
                        }
                      }}
                      className="flex-1 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-medium py-3 px-4 rounded-lg transition-all duration-200 flex items-center justify-center"
                    >
                      📋 Lihat Detail Tabel
                    </button>
                    <button
                      onClick={async () => {
                        try {
                          const jobData = await apiCall(`/api/jobs/${currentJob.job_id}`);
                          const csvContent = generateCSV(jobData.results?.details || []);
                          downloadCSV(csvContent, `validation-results-${currentJob.job_id}.csv`);
                          toast.success('File CSV berhasil didownload!');
                        } catch (error) {
                          toast.error('Gagal mendownload hasil');
                        }
                      }}
                      className="flex-1 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-medium py-3 px-4 rounded-lg transition-all duration-200 flex items-center justify-center"
                    >
                      📥 Download CSV
                    </button>
                  </div>
                  
                  <button
                    onClick={() => {
                      // Keep modal open but mark as accessible for later
                      toast.success('Hasil telah tersimpan! Anda dapat mengaksesnya kapan saja di bagian "Hasil Validasi Terbaru" di bawah.');
                    }}
                    className="w-full bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 font-medium py-2 px-4 rounded-lg transition-all duration-200"
                  >
                    ✅ Tutup - Hasil Tersimpan
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Results Detail Modal */}
      {showResultsModal && jobResults && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-6xl w-full mx-4 max-h-[90vh] overflow-hidden">
            <div className="p-6 border-b border-gray-200 dark:border-gray-600">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  📋 Detail Hasil Validasi
                </h3>
                <button
                  onClick={() => setShowResultsModal(false)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
                >
                  ✕
                </button>
              </div>
            </div>

            <div className="p-6">
              {/* Summary Stats */}
              <div className="grid grid-cols-4 gap-4 mb-6">
                <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                    {jobResults.results?.whatsapp_active || 0}
                  </p>
                  <p className="text-sm text-green-600 dark:text-green-400">WA Aktif</p>
                </div>
                <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                    {jobResults.results?.telegram_active || 0}
                  </p>
                  <p className="text-sm text-blue-600 dark:text-blue-400">TG Aktif</p>
                </div>
                <div className="bg-gray-50 dark:bg-gray-700/20 rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-gray-600 dark:text-gray-400">
                    {jobResults.total_numbers || 0}
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total</p>
                </div>
                <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-3 text-center">
                  <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                    {jobResults.credits_used || 0}
                  </p>
                  <p className="text-sm text-purple-600 dark:text-purple-400">Kredit</p>
                </div>
              </div>

              {/* Results Table */}
              <div className="overflow-x-auto">
                <div className="max-h-96 overflow-y-auto">
                  <table className="w-full border-collapse">
                    <thead className="sticky top-0 bg-white dark:bg-gray-800 z-10">
                      <tr className="border-b-2 border-gray-200 dark:border-gray-600">
                        <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">No.</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Nama</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Nomor</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">WhatsApp</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-900 dark:text-white">Telegram</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(jobResults.results?.details || [])
                        .slice((resultsPage - 1) * RESULTS_PER_PAGE, resultsPage * RESULTS_PER_PAGE)
                        .map((detail, index) => (
                          <tr key={index} className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                            <td className="py-3 px-4 text-sm text-gray-600 dark:text-gray-400">
                              {(resultsPage - 1) * RESULTS_PER_PAGE + index + 1}
                            </td>
                            <td className="py-3 px-4">
                              {detail.identifier ? (
                                <span className="text-sm font-medium text-gray-900 dark:text-white">
                                  {detail.identifier}
                                </span>
                              ) : (
                                <span className="text-gray-400 text-sm">—</span>
                              )}
                            </td>
                            <td className="py-3 px-4 font-mono text-sm">
                              {detail.phone_number}
                            </td>
                            <td className="py-3 px-4">
                              {detail.whatsapp ? (
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                  detail.whatsapp.status === 'active' 
                                    ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                                    : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                                }`}>
                                  {detail.whatsapp.status === 'active' ? 'Aktif' : 'Tidak Aktif'}
                                </span>
                              ) : (
                                <span className="text-gray-400 text-xs">—</span>
                              )}
                            </td>
                            <td className="py-3 px-4">
                              {detail.telegram ? (
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                  detail.telegram.status === 'active' 
                                    ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                                    : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                                }`}>
                                  {detail.telegram.status === 'active' ? 'Aktif' : 'Tidak Aktif'}
                                </span>
                              ) : (
                                <span className="text-gray-400 text-xs">—</span>
                              )}
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Pagination */}
              {(jobResults.results?.details || []).length > RESULTS_PER_PAGE && (
                <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    Menampilkan {(resultsPage - 1) * RESULTS_PER_PAGE + 1} - {Math.min(resultsPage * RESULTS_PER_PAGE, (jobResults.results?.details || []).length)} dari {(jobResults.results?.details || []).length} hasil
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => setResultsPage(prev => Math.max(1, prev - 1))}
                      disabled={resultsPage === 1}
                      className="px-3 py-1 border rounded text-sm disabled:opacity-50"
                    >
                      Sebelumnya
                    </button>
                    <button
                      onClick={() => setResultsPage(prev => prev + 1)}
                      disabled={resultsPage * RESULTS_PER_PAGE >= (jobResults.results?.details || []).length}
                      className="px-3 py-1 border rounded text-sm disabled:opacity-50"
                    >
                      Berikutnya
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Helper functions for CSV download
const generateCSV = (details) => {
  const headers = ['No', 'Nama', 'Nomor', 'WhatsApp', 'Telegram'];
  const rows = details.map((detail, index) => [
    index + 1,
    detail.identifier || '',
    detail.phone_number,
    detail.whatsapp ? (detail.whatsapp.status === 'active' ? 'Aktif' : 'Tidak Aktif') : '',
    detail.telegram ? (detail.telegram.status === 'active' ? 'Aktif' : 'Tidak Aktif') : ''
  ]);
  
  return [headers, ...rows].map(row => row.join(',')).join('\n');
};

const downloadCSV = (csvContent, fileName) => {
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', fileName);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export default BulkCheck;